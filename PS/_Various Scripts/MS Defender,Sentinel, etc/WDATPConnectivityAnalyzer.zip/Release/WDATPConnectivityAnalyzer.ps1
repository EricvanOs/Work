param (
    [string]$outputDir = $PSScriptRoot,
    [Alias("p", "proxy")][string]$manualProxy = "",
    [Alias("n", "net")][switch]$netTrace,
    [Alias("w", "wfp")][switch]$wfpTrace
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8  # WDATPConnectivityAnalyzer.exe outputs UTF-8, so interprete its output as such

# Define outputs
$resultOutputDir = Join-Path $outputDir "WDATPConnectivityAnalyzerResult"
$traceFile = Join-Path $resultOutputDir "NetTrace.etl"
$connectivityCheckFile = Join-Path $resultOutputDir "WDATPConnectivityAnalyzer.txt"
$connectivityCheckUserFile = Join-Path $resultOutputDir "WDATPConnectivityAnalyzer_User.txt"
$outputZipFile = Join-Path $outputDir "WDATPConnectivityAnalyzerResult.zip"
$trancriptfile = Join-Path  $resultOutputDir "WDATPConnectivityOutput.txt"
$OSPreviousVersion = $false
$EndpointList = Join-Path $outputDir "endpoints.txt"

# function to read Registry Value
function Get-RegistryValue { param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Path,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$Value
    )

    if (Test-Path -path $Path) {
        return Get-ItemProperty -Path $Path | Select-Object -ExpandProperty $Value -ErrorAction silentlycontinue
    } else {
        return $false
    }
}

function StartTraces() {
    if ($netTrace) {
        netsh trace start capture=yes report=yes traceFile=$traceFile fileMode=single
    }
    if ($wfpTrace) {
        netsh advfirewall set allprofiles logging allowedconnections enable   # enable firewall logging for allowed traffic
        netsh advfirewall set allprofiles logging droppedconnections enable   # enable firewall logging for dropped traffic
        netsh wfp capture start keywords=19   # start capturing  WFP log
    }
}

function StopTraces() {
    if ($netTrace) {
        netsh trace stop
    }
    if ($wfpTrace) {
        netsh wfp capture stop
        Move-Item -Path .\wfpdiag.cab $resultOutputDir
        Copy-Item $env:SystemRoot\system32\LogFiles\Firewall\pfirewall.log -Destination $resultOutputDir
    }
}

function SetUrlList {
    param (
        [parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]$OSPreviousVersion
    )
    $regionInfos = @{
        US=@{cnc1='eus'; cnc2='cus'; vortex='us'};
        EU=@{cnc1='neu'; cnc2='weu'; vortex='eu'};
        UK=@{cnc1='ukw'; cnc2='uks'; vortex='uk'};
        FFL4=@{cnc1='usgv'; cnc2='usgt'; vortex='us4'};
        FFL5=@{cnc1='usde'; cnc2='usdc'; vortex='us5'};
    }
    $cncurl = "https://winatp-gw-toreplace.microsoft.com/test"
    $vortexurl = "https://toreplace.vortex-win.data.microsoft.com/health/keepalive"
    $vortexurlv20 = "https://toreplace-v20.events.data.microsoft.com/ping"
    if (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value OnboardingState ){
        $Region = (((Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows Advanced Threat Protection\").OnboardingInfo | ConvertFrom-Json).body | ConvertFrom-Json).vortexGeoLocation
        Clear-Content -Path $EndpointList
        Add-Content $EndpointList -value $cncurl.Replace('toreplace',$regionInfos.($Region).cnc1)
        Add-Content $EndpointList -value $cncurl.Replace('toreplace',$regionInfos.($Region).cnc2)
        if (($Region) -notmatch 'FFL'){
            # Exsist only for not FF tenants
                Add-Content $EndpointList -value $vortexurl.Replace('toreplace',$regionInfos.($Region).vortex)
                Add-Content $EndpointList -Value "http://ctldl.windowsupdate.com/msdownload/update/v3/static/trustedr/en/disallowedcertstl.cab	NoPinning"
            }
            Add-Content $EndpointList -value $vortexurlv20.Replace('toreplace',$regionInfos.($Region).vortex)
    }
    elseif ($OSPreviousVersion) {
        Clear-Content -Path $EndpointList
        $Rregions = ('US','UK','EU')
         foreach ($Region in $Rregions){
            Add-Content $EndpointList -value $cncurl.Replace('toreplace',$regionInfos.($Region).cnc1)
            Add-Content $EndpointList -value $cncurl.Replace('toreplace',$regionInfos.($Region).cnc2)
        }
    }
}


function CheckConnectivity { param (
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$OSPreviousVersion,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$connectivityCheckFile,
    [parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]$connectivityCheckUserFile
    )

    [version]$mindotNet="4.0.30319"
    
    SetUrlList -OSPreviousVersion $OSPreviousVersion

    if ((Get-RegistryValue -Path  "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -Value Version)) {
        [version]$dotNet = Get-RegistryValue -Path  "HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Client" -Value Version
    } else {
        [version]$dotNet = "0.0.0000"
    }

    if (!$OSPreviousVersion) {
        StartTraces        

        & ($PSScriptRoot + "\PsExec.exe") -accepteula -s -w $PSScriptRoot $PSScriptRoot\WDATPConnectivityAnalyzer.exe -p $manualProxy >> $connectivityCheckFile

        # Run the tool as interactive user (for authenticated proxy scenario)
        & $PSScriptRoot\WDATPConnectivityAnalyzer.exe -p $manualProxy > $connectivityCheckUserFile

        StopTraces
    }
    elseif ($dotNet -ge $mindotNet) {
        StartTraces

        $PSexecCommand = Join-Path $outputDir "PsExec.exe"
        $WDATPConnectivityAnalyzerPreviousVersionCommand = Join-Path $outputDir "WDATPConnectivityAnalyzerPreviousVersion.exe"
            
        $Global:connectivityresult = (& $PSexecCommand -accepteula -s -w $outputDir $WDATPConnectivityAnalyzerPreviousVersionCommand )
        # Run the tool as interactive user (for authenticated proxy scenario)
        $Global:connectivityresultUser = (& $WDATPConnectivityAnalyzerPreviousVersionCommand)
            
        #Run MMA Conectivity tool
        $MMARootFolder = "$env:ProgramFiles\Microsoft Monitoring Agent\Agent"
        if(Test-Path -path $MMARootFolder){
            $Global:TestOMSResult = & $MMARootFolder\TestCloudConnection.exe 
        }

        StopTraces
    } else {
        Write-Host -BackgroundColor Red -ForegroundColor Yellow "To run URI validation tool please install .NET framework 4.0  or higher"
            "To run URI validation tool please install .NET framework 4.0 or higher" | Out-File $connectivityCheckFile -Append
        $Global:connectivityresult = $false
        $Global:connectivityresultUser = $false
        $Global:TestOMSResult = $false
    }

    if ('$env:SystemRoot\\System32\wintrust.dll') {
        [version]$wintrustMinimumFileVersion = '6.1.7601.23971'
        $wintrustprops = @{
            Message = ""
            Valid = $true
            Version = [string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\wintrust.dll).VersionInfo).FilePrivatePart
        }
        $Global:wintrustdll = new-object psobject -Property $wintrustprops

        if (([version]$Global:wintrustdll.version -lt $wintrustMinimumFileVersion) ) {
            $Global:wintrustdll.Valid = $false
            $Global:wintrustdll.Message = "######################################### Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ " ################# `nWDATP can't start - it requires wintrust.dll version $wintrustMinimumFileVersion or higher, while this machine has version " + $wintrustdll.version + ". `n" `
                +"You should install one of the following updates:`n" `
                +"* KB4057400 - 2018-01-19 preview of monthly rollupn.`n" `
                +"* KB4074598 - 2018-02-13 monthly rollup.`n" `
                +"* A later monthly rollup that supersedes them.`n" `
                +"#########################################################################################################################"
        } else {
            $Global:wintrustdll.Message = "The version " +$Global:wintrustdll.version +" of wintrust.dll is supported"
        }
    }

    if (('$env:SystemRoot\\System32\tdh.dll')) {
        [version]$gdrTdhMinimumFileVersion = '6.1.7601.18939'
        [version]$ldrMinimumFileVersion = '6.1.7601.22000'
        [version]$ldrTdhMinimumFileVersion = '6.1.7601.23142'
        $tdhprops = @{
            Message = ""
            Valid = $true
            Version = [string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductMajorPart +'.' +[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductMinorPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).ProductBuildPart +'.'+[string]((Get-ItemProperty -Path $env:SystemRoot\\System32\tdh.dll).VersionInfo).FilePrivatePart
        }
        $Global:tdhdll = new-object psobject -Property $tdhprops

        if ([version]$Global:tdhdll.Version -lt $gdrTdhMinimumFileVersion) {
            $Global:tdhdll.Valid = $false
            $Global:tdhdll.Message =  "######################################### Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ " ################# `nWDATP can't start - it requires tdh.dll version $gdrTdhMinimumFileVersion or higher, while this machine has version " + $tdhdll.version + ". `n" `
                +"You should install the following update:`n" `
                +"* KB3080149 - Update for customer experience and diagnostic telemetry.`n" `
                +"#########################################################################################################################"
        }
        elseif ([version]$Global:tdhdll.Version -ge $ldrMinimumFileVersion -and [version]$tdhdll.Version -lt $ldrTdhMinimumFileVersion) {
            $Global:tdhdll.Valid = $false
            $Global:tdhdll.Message =  "######################################### Environment is not supported: "+[System.Environment]::OSVersion.VersionString+ " ################# `nWDATP can't start - it requires tdh.dll version $ldrTdhMinimumFileVersion or higher, while this machine has version " + $tdhdll.version + ". `n" `
                +"You should install the following update:`n" `
                +"* KB3080149 - Update for customer experience and diagnostic telemetry.`n" `
                +"#########################################################################################################################"
        } else {
            $Global:tdhdll.Message = "The version " +$Global:tdhdll.version +" of tdh.dll is supported"
        }
    }

    $protocol = [Enum]::ToObject([System.Net.SecurityProtocolType], 3072)
    [string]$global:sslprotocol = $null
    try {
        [System.Net.ServicePointManager]::SecurityProtocol = $protocol
    } catch [System.Management.Automation.SetValueInvocationException] {
        $global:sslprotocol = "`n############################################ Environment is not supported , the missing KB must be installed ##################`n"`
            +"Environment is not supported: " +[System.Environment]::OSVersion.VersionString+", WDATP requires TLS 1.2 support in .NET framework 3.5.1, exception "+$_.Exception.Message +" . You should install the following updates:`n" `
            +"* KB3154518 - Support for TLS System Default Versions included in the .NET Framework 3.5.1 on Windows 7 SP1 and Server 2008 R2 SP1`n"`
            +"* .NET framework 4.0 or later.`n"`
            +"########################################################################################################################" 
    } Catch [Exception] {
        $global:sslprotocol = $_.Exception.Message
    }
}




#Main
[int]$OSBuild = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value CurrentBuild
[string]$OSEditionID = Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value EditionID
[string]$OSProductName =  Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value ProductName

# Delete previous output if exists
if(Test-Path $resultOutputDir) {
    Remove-Item -Recurse -Force $resultOutputDir
}
if(Test-Path $outputZipFile) {
    Remove-Item -Recurse -Force  $outputZipFile
}

# Create output folder
New-Item -ItemType directory -Path $resultOutputDir | Out-Null



"Machine build number is: " + [System.Environment]::OSVersion.VersionString | Out-File $connectivityCheckFile -append
Write-output "############################ Machine Info summary ####################################" | Out-File $connectivityCheckFile -append
if ((($OSBuild -ge 7601 -and $OSBuild -le 14393) -and ($OSProductName -notmatch 'Windows 10')) -and (($OSEditionID -match 'Enterprise') -or ($OSEditionID -match 'Pro') -or ($OSEditionID -match 'Ultimate') -or ($OSEditionID -match 'Server'))) {
    $OSPreviousVersion = $true
    CheckConnectivity -OSPreviousVersion $OSPreviousVersion -connectivityCheckFile $connectivityCheckFile -connectivityCheckUserFile $connectivityCheckUserFile
      
    if ($Global:tdhdll.Valid -and $Global:wintrustdll.Valid -and !($global:sslprotocol)) {
        "OS Environment is  supported: "+[System.Environment]::OSVersion.VersionString | Out-File $connectivityCheckFile -append
    } else {
        "OS Environment is not  supported: "+[System.Environment]::OSVersion.VersionString + " More inforamation below" | Out-File $connectivityCheckFile -append
    }

    if ($Global:connectivityresult -match "failed" ) {
        "Command and Control channel as Sytem Account : Some of the WDATP APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:connectivityresult) {
        "Command and Control channel as Sytem Account: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "Command and Control channel as Sytem Account: Passed validation" | Out-File $connectivityCheckFile -append 
    }

    if ($Global:connectivityresultUser -match "failed" ) {
        "Command and Control channel as User Account : Some of the WDATP APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:connectivityresultUser) {
        "Command and Control channel as User Account: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "Command and Control channel as User Account: Passed validation" | Out-File $connectivityCheckFile -append 
    }

    if ($Global:TestOMSResult -match "Connection failed" -or $Global:TestOMSResult -match "Blocked Host") {
        "OMS channel : Some of the OMS APIs failed , see details below" | Out-File $connectivityCheckFile -append
    } elseif (!$Global:TestOMSResult) {
        "OMS channel: Not tested" | Out-File $connectivityCheckFile -append 
    } else {
        "OMS channel:  Passed validation" | Out-File $connectivityCheckFile -append 
    }

    if ((Get-RegistryValue -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\" -Value "senseId")) {
        "Sense ID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\" -Value "senseId" ) | Out-File $connectivityCheckFile -append
        "Service Microsoft Monitoring Agent is " + (Get-Service -Name HealthService -ErrorAction SilentlyContinue).Status | Out-File $connectivityCheckFile -append
        "Sense Configuration Version is : " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Advanced Threat Protection\Status" -Value "ConfigurationVersion" ) | Out-File $connectivityCheckFile -append
    } else {
        "Machine is: not onboarded" | Out-File $connectivityCheckFile -append
    }

    if (Test-Path -Path  $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx') {
        Copy-Item -path $env:SystemRoot\System32\'Winevt\Logs\Operations Manager.evtx' -Destination $resultOutputDir\OperationsManager.evtx
    }

    Write-output "##########################################################################" | Out-File $connectivityCheckFile -append  
} else {
    if ((Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value OnboardingState ) -eq $True) {
        "Machine is: onboarded" | Out-File $connectivityCheckFile -append
        (Get-WinEvent -ProviderName Microsoft-Windows-SENSE | Where-Object -Property Message -Like "*ID calculated*" | select -L 1).Message | Out-File $connectivityCheckFile -append
        "Sense GUID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection" -Value "senseGuid" ) | Out-File $connectivityCheckFile -append
        "Sense OrdID is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value "OrgID" ) | Out-File $connectivityCheckFile -append
        "Sense service state is: " + (Get-Service -Name Sense).Status | Out-File $connectivityCheckFile -append
        "UTC service state is: " + (Get-Service -Name DiagTrack).Status | Out-File $connectivityCheckFile -append
        "Defender service state is: " + (Get-Service -Name WinDefend).Status | Out-File $connectivityCheckFile -append
        "Microsoft Account Sign-in Assistant service start type is: " + (Get-Service -Name wlidsvc).StartType | Out-File $connectivityCheckFile -append
        if (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender" -Value "PassiveMode") {
                "Windows Defender is in passive mode" | Out-File $connectivityCheckFile -append
        }
        "Windows Defender AV Signature Version is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Signature Updates" -Value "AVSignatureVersion" )  + "  Engine Version is: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows Defender\Signature Updates" -Value "EngineVersion" )  | Out-File $connectivityCheckFile -append
        "Last Sense Seen TimeStamp: " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows Advanced Threat Protection\Status" -Value LastConnected ) | Out-File $connectivityCheckFile -append

        if ((Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\" -value ReleaseId) -eq 1607) {
            "Last SevilleDiagTrack LastNormalUploadTime TimeStamp : " + (Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\SevilleSettings -Value LastNormalUploadTime) | Out-File $connectivityCheckFile -append
            "Last SevilleDiagTrack LastRealtimeUploadTime TimeStamp: " + (Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\SevilleSettings -Value LastRealtimeUploadTime) | Out-File $connectivityCheckFile -append
            "Last SevilleDiagTrack LastHeartBeatTime TimeStamp: " + (Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville\ -Value LastHeartBeatTime) | Out-File $connectivityCheckFile -append
            "Last SevilleDiagTrack LastInvalidHttpCode : " + (Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville\ -Value LastInvalidHttpCode)  | Out-File $connectivityCheckFile -append
        } else {
            "Last SevilleDiagTrack LastNormalUploadTime TimeStamp : " + (Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-WDATP -Value LastNormalUploadTime) | Out-File $connectivityCheckFile -append
            "Last SevilleDiagTrack LastRealtimeUploadTime TimeStamp: " + (Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-WDATP -Value LastRealtimeUploadTime) | Out-File $connectivityCheckFile -append
            "Last SevilleDiagTrack LastHeartBeatTime TimeStamp: " + ( Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville\ -Value LastHeartBeatTime) | Out-File $connectivityCheckFile -append
            "Last SevilleDiagTrack LastInvalidHttpCode : " + (Get-RegistryValue -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\HeartBeats\Seville\ -Value LastInvalidHttpCode) | Out-File $connectivityCheckFile -append
        }

        if (test-path -Path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-UniversalTelemetryClient%4Operational.evtx') {
            Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-UniversalTelemetryClient%4Operational.evtx -Destination $resultOutputDir\utc.evtx
        }
        if (Test-Path -Path $env:SystemRoot\System32\'Winevt\Logs\Microsoft-Windows-SENSE%4Operational.evtx') {
            Copy-Item -path $env:SystemRoot\System32\Winevt\Logs\Microsoft-Windows-SENSE%4Operational.evtx -Destination $resultOutputDir\sense.evtx
        }
    } else {
        "Machine is: not onboarded" | Out-File $connectivityCheckFile -append
    }

    CheckConnectivity -OSPreviousVersion $OSPreviousVersion -connectivityCheckFile $connectivityCheckFile -connectivityCheckUserFile $connectivityCheckUserFile
    Write-output "##########################################################################" | Out-File $connectivityCheckFile -append
}



Write-output " " | Out-File $connectivityCheckFile -append
if ((($OSBuild -ge 7601 -and $OSBuild -le 14393) -and ($OSProductName -notmatch 'Windows 10')) -and (($OSEditionID -match 'Enterprise') -or ($OSEditionID -match 'Pro') -or ($OSEditionID -match 'Ultimate') -or ($OSEditionID -match 'Server'))) {
    "###################### OS validation  details  ############" | Out-File $connectivityCheckFile -append
    $Global:tdhdll.Message  | Out-File $connectivityCheckFile -append
    $Global:wintrustdll.Message  | Out-File $connectivityCheckFile -append
    $global:sslprotocol | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
    "###################### Connectivity details for Command and Control  validation  ############" | Out-File $connectivityCheckFile -append
    $connectivityresult | Out-File $connectivityCheckFile -append
    $Global:connectivityresultUser  | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
    "###################### Connectivity details for OMS  validation  ############" | Out-File $connectivityCheckFile -append
    $Global:TestOMSResult | Out-File $connectivityCheckFile -append
    Write-output "##########################################################################`n" | Out-File $connectivityCheckFile -append  
}

"######################Connectivity Check for ctldl.windowsupdate.com ############" | Out-File $connectivityCheckFile -append
$urlctldl =  "http://ctldl.windowsupdate.com/msdownload/update/v3/static/trustedr/en/pinrulesstl.cab"
$webRequest = [net.WebRequest]::Create("$urlctldl")
try {
    "StatusCode for " + $urlctldl + " IS : " + $webrequest.GetResponse().StatusCode | Out-File $connectivityCheckFile -append
} catch [System.Net.WebException] {
    "StatusCode for "+ $urlctldl+ " IS : " + $_.Exception.Response.StatusCode + $_.Exception.Response.StatusCode.Value__ | Out-File $connectivityCheckFile -append
}

Write-output " " | Out-File $connectivityCheckFile -append
"############################PROXY SETTINGS################################" | Out-File $connectivityCheckFile -append
 
if (!(Get-RegistryValue -Path "HKLM:\SOFTWARE\Microsoft\\Windows\CurrentVersion\Internet Settings" -Value "ProxyServer")) {
    "Proxy settings in machine level are not detected" | Out-File $connectivityCheckFile -append
} else {
    "Proxy settings in machine level are :  " + (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
}

if ((Get-RegistryValue -Path "HKLM:SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" -Value "ProxyEnable") -eq $true) {
    "Proxy setting in user level are :  "+ (Get-RegistryValue -Path "HKLM:\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" -Value "ProxyServer" ) | Out-File $connectivityCheckFile -append
} else {
    "Proxy setting in user level are not detected" | Out-File $connectivityCheckFile -append
}

(netsh winhttp show proxy) | Out-File $connectivityCheckFile -append

[version]$PSminver = '2.0.1.1'
if ( $PSVersionTable.PSVersion -gt $PSminver) {
    Add-Type -Assembly "System.IO.Compression.FileSystem";
    [System.IO.Compression.ZipFile]::CreateFromDirectory($resultOutputDir, $outputZipFile)
    Write-Host "Result is available at: " $outputZipFile
} else {
     Write-Host "Result is available at: " $resultOutputDir
}

# SIG # Begin signature block
# MIIkWwYJKoZIhvcNAQcCoIIkTDCCJEgCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDOg9PwhHrrmksY
# bLhXqWgWUrKgO3wRqfNlG174839Rd6CCDYEwggX/MIID56ADAgECAhMzAAABUZ6N
# j0Bxow5BAAAAAAFRMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTkwNTAyMjEzNzQ2WhcNMjAwNTAyMjEzNzQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCVWsaGaUcdNB7xVcNmdfZiVBhYFGcn8KMqxgNIvOZWNH9JYQLuhHhmJ5RWISy1
# oey3zTuxqLbkHAdmbeU8NFMo49Pv71MgIS9IG/EtqwOH7upan+lIq6NOcw5fO6Os
# +12R0Q28MzGn+3y7F2mKDnopVu0sEufy453gxz16M8bAw4+QXuv7+fR9WzRJ2CpU
# 62wQKYiFQMfew6Vh5fuPoXloN3k6+Qlz7zgcT4YRmxzx7jMVpP/uvK6sZcBxQ3Wg
# B/WkyXHgxaY19IAzLq2QiPiX2YryiR5EsYBq35BP7U15DlZtpSs2wIYTkkDBxhPJ
# IDJgowZu5GyhHdqrst3OjkSRAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUV4Iarkq57esagu6FUBb270Zijc8w
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU0MTM1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAWg+A
# rS4Anq7KrogslIQnoMHSXUPr/RqOIhJX+32ObuY3MFvdlRElbSsSJxrRy/OCCZdS
# se+f2AqQ+F/2aYwBDmUQbeMB8n0pYLZnOPifqe78RBH2fVZsvXxyfizbHubWWoUf
# NW/FJlZlLXwJmF3BoL8E2p09K3hagwz/otcKtQ1+Q4+DaOYXWleqJrJUsnHs9UiL
# crVF0leL/Q1V5bshob2OTlZq0qzSdrMDLWdhyrUOxnZ+ojZ7UdTY4VnCuogbZ9Zs
# 9syJbg7ZUS9SVgYkowRsWv5jV4lbqTD+tG4FzhOwcRQwdb6A8zp2Nnd+s7VdCuYF
# sGgI41ucD8oxVfcAMjF9YX5N2s4mltkqnUe3/htVrnxKKDAwSYliaux2L7gKw+bD
# 1kEZ/5ozLRnJ3jjDkomTrPctokY/KaZ1qub0NUnmOKH+3xUK/plWJK8BOQYuU7gK
# YH7Yy9WSKNlP7pKj6i417+3Na/frInjnBkKRCJ/eYTvBH+s5guezpfQWtU4bNo/j
# 8Qw2vpTQ9w7flhH78Rmwd319+YTmhv7TcxDbWlyteaj4RK2wk3pY1oSz2JPE5PNu
# Nmd9Gmf6oePZgy7Ii9JLLq8SnULV7b+IP0UXRY9q+GdRjM2AEX6msZvvPCIoG0aY
# HQu9wZsKEK2jqvWi8/xdeeeSI9FN6K1w4oVQM4Mwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIWMDCCFiwCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAVGejY9AcaMOQQAAAAABUTAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgLsjV3GU9
# zKke/nyYh0nCknGrU38FwFz4mjxD7M9nSMAwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQCRRLXQlAAeqhpa5dqgzsLq4q9noG2nLiQ140KaFiOM
# 0ojFH2gAoHpOFfjNlvPJPwM7FRYhN2qj/+IUj2fE4PoczoH9i/XU4Fq5d0ultd9v
# pFYs1X+SBAr+Tfv92yI+e7Lsny6dsexUPdRV6AfmCIlefS8PZVe2nRWEvNvDXaAg
# zoECvo2zRM4SIJiO3pet/+23C/pfwXPWxFl5HDwr6swWl68VhSweIDQ8YP79+DLx
# ZO8huOhRNv1Rx/9bN3KnQgBkq2WNZpn4Bs/1WkhyVv1RsUcciXA1mKMQrBaWVMq/
# k82aaLdK6z51UnIv9Null0EoDgdDzGI4D9ns0YtufRiboYITujCCE7YGCisGAQQB
# gjcDAwExghOmMIITogYJKoZIhvcNAQcCoIITkzCCE48CAQMxDzANBglghkgBZQME
# AgEFADCCAVgGCyqGSIb3DQEJEAEEoIIBRwSCAUMwggE/AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEICyO5B1Hk/xmr/bC5umJzz7C+T6ubfNp/m6jLRqU
# CeddAgZdFkBlRXQYEzIwMTkwNzA3MDgyODM2Ljg3NFowBwIBAYACAfSggdSkgdEw
# gc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsT
# IE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFs
# ZXMgVFNTIEVTTjo3MjhELUM0NUYtRjlFQjElMCMGA1UEAxMcTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgU2VydmljZaCCDyIwggT1MIID3aADAgECAhMzAAAA09CUVp0OvYMG
# AAAAAADTMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAy
# MDEwMB4XDTE4MDgyMzIwMjY0MFoXDTE5MTEyMzIwMjY0MFowgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo3
# MjhELUM0NUYtRjlFQjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK7ynC6AF22joS/v
# TPZsIG82oovZ8kXNQcF6/17dZtRllU6pCGV8zMxSQOXTWD2MZRJ/OqfHUSYCNTPa
# knetNsrZhstlFNT09QBjjeVXayDG/aI8JPy91P5riOAFk/gvjnQCdcoV65OBF286
# bs2lgUa6rc2qKHwDVpR1w+2jXrS8Jtz6omUgfB7CMpw1ZwMeQ/+Fb43EAIxeNXB5
# uq/ZYPDA+iMitkdhrjQJgPKKQqhPiYcz3KdrAk34V6y/zUw8FuJ9Zi89actfoS0e
# AdSdWYDATi6oIiPAioWYQuwx6ZY+e5U8HcjGiA1bg9pnufqcnVLzInBxr8DVp1im
# mAhtkfUCAwEAAaOCARswggEXMB0GA1UdDgQWBBQoUcoPr2oQO5sHaVpYVKDsatRn
# eDAfBgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQA9YvD9FBa0sIj/Q8252GXwW0qQ
# aEm/oZXTh4eI6htIKASVxX8y1g4IVeD6O8YyXdBlzQUgr76B70pDgqyynwmJK6KB
# pg2bf6KOeHImc4pmofFc9EhYLZgXPXwqHJY1Rgwt4X1kCNNK6PTGeFlJproYry38
# a8AuUm0oLJpf46TLC4wQv89vfyEhBed/Wv95Ro5fqn/tAQc8S/c0eq1CAdkMDzsJ
# q7lZmiEAMaVF0vKrcRvtVu7T5BZcTmP6bHNtzcDxnn7rB6TUgSREnWP5Di46Z9P6
# 0XraNff0Ttit5Msy8ivsrcEa2CIxUgscbYDxAaWR8Ghb/rTVIEEWYBAVrF9vMIIG
# cTCCBFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1
# WhcNMjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9p
# lGt0VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEw
# WbEwRA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeG
# MoQedGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJ
# UGKxXf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw
# 2k4GkbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0C
# AwEAAaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8E
# BAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2U
# kFvXzpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5j
# b20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmww
# WgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYD
# VR0gAQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYI
# KwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0
# AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9
# naOhIW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtR
# gkQS+7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzy
# mXlKkVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCf
# Mkon/VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3D
# nKOiPPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs
# 9/S/fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110
# mCIIYdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL
# 2IK0cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffI
# rE7aKLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxE
# PJdQcdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc
# 1bN+NR4Iuto229Nfj950iEkSoYIDsDCCApgCAQEwgf6hgdSkgdEwgc4xCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29m
# dCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# Tjo3MjhELUM0NUYtRjlFQjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIlCgEBMAkGBSsOAwIaBQADFQBnQlpxrvQi2lklNcOL1G5qmRJdZ6CB
# 3jCB26SB2DCB1TELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEp
# MCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJzAlBgNV
# BAsTHm5DaXBoZXIgTlRTIEVTTjo0REU5LTBDNUUtM0UwOTErMCkGA1UEAxMiTWlj
# cm9zb2Z0IFRpbWUgU291cmNlIE1hc3RlciBDbG9jazANBgkqhkiG9w0BAQUFAAIF
# AODL+h8wIhgPMjAxOTA3MDcxMjU3MDNaGA8yMDE5MDcwODEyNTcwM1owdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA4Mv6HwIBADAKAgEAAgIEqAIB/zAHAgEAAgIWyjAK
# AgUA4M1LnwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMBoAowCAIB
# AAIDFuNgoQowCAIBAAIDB6EgMA0GCSqGSIb3DQEBBQUAA4IBAQCPw6XeUZlpH03a
# EMSTpCGa+/JB8Kgny4GbMcCCEoNuNjMJSxSQQQJGGd29CQauJoHLskhgOOeoY0DE
# 13miipOq5/6pqxxQQ3gMBWHqbx08fXdojH1lfQVPkoaEVJG1pk/hAP9vaMf9WtJm
# yW5zD/l9P6dZy+bJwSMkRvjN8/OvzlCvUlSU4/Nat5+PzRLz2LrTe5MphNY52S29
# I7Gk7cyvPSl3Zxl6TwuNNnyIowr1kAVhtY92YZ1ewInjTNlKc1ydRpn0LHuLMv+R
# 3QmAnJFy+FLo/z7ewnQ4Bgta9wLNnNCizYH+vORG4V6MoTHyuC8MzPGhSvzsryQ5
# 5I/1GidcMYIC9TCCAvECAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTACEzMAAADT0JRWnQ69gwYAAAAAANMwDQYJYIZIAWUDBAIBBQCgggEyMBoGCSqG
# SIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgLvqt76qGULI3
# 9dlnhl2nV2kqg2X6sAV8/Qg4ppMTDC0wgeIGCyqGSIb3DQEJEAIMMYHSMIHPMIHM
# MIGxBBRnQlpxrvQi2lklNcOL1G5qmRJdZzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFBDQSAyMDEwAhMzAAAA09CUVp0OvYMGAAAAAADTMBYEFGkB81afbcU2
# 8ngMknD9aw5nqaR0MA0GCSqGSIb3DQEBCwUABIIBAADhLO3irhxnFljOKUnGMVlS
# 1X92XQouarLZnlfWwoCBW8K/GKJ1b0tl6LbUuo+eI2MHONF0dRML2/qSG991qnjv
# 3zMm+Jk0EnGlF8p0sewIvsmtIfDUDWgT2fBIrVOAnxkbD3cbOFo6B1FnNc6pJPiC
# 9avGH+/rFw216/aG7lqAPpWiXxYSJLoeeJLYJvmRyzeC6XlSeR/Rt7mSroWlZt0+
# /0YHltA1K3MZ/zcRNUf8J5pfYeN0e2F572v51unp/8bAUEx3lSNXmJTpSx0poWrK
# Xc5l7fODiewEYemoZLtnlnwuSAG7+cTFjisYmbsaW8iOqJTo65JFAcEUeUt5QjI=
# SIG # End signature block
