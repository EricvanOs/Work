/*
========================================================================================
 Author:	  Marco Baars
 Create date: 16-11-2016
 Last update: 16-11-2016
 Description: Get job GUID of subscription by reportname and execute if data is returned
========================================================================================
*/

DECLARE @ReportName varchar(100)
DECLARE @ReportGuid varchar(150)
DECLARE @ExpiredCertificates int

SET @ReportName = 'CertificateAdministration'

/*
========================================================================================
*/

SET @ReportGuid = (SELECT rs.ScheduleID
FROM
      ReportServer..[Catalog] c
      JOIN ReportServer..Subscriptions s ON c.ItemID = s.Report_OID
      JOIN ReportServer..ReportSchedule rs ON c.ItemID = rs.ReportID
      AND rs.SubscriptionID = s.SubscriptionID WHERE c.Name = @ReportName)
      
PRINT @ReportGuid   

SET @ExpiredCertificates = (SELECT COUNT(*)
FROM [CYG7000].[ICT].[dbo].[Tbl_CertificateAdministration]
WHERE DATEDIFF(ww,GETDATE(),[ExpirationDate]) < 6 AND [ExpirationDate] > GETDATE())  

PRINT @ExpiredCertificates

USE MSDB
IF @ExpiredCertificates > 0
EXEC dbo.sp_start_job @ReportGuid 






