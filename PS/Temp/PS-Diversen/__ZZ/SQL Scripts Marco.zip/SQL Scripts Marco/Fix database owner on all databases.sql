DECLARE @dbname NVARCHAR(50) -- database name 
DECLARE @selectdb NVARCHAR(150) -- holder for selecting database

DECLARE nosa CURSOR FOR
SELECT name FROM sys.databases WHERE suser_sname(owner_sid) <> 'sa'
AND name not in ('master', 'model', 'tempdb', 'msdb')

OPEN nosa
FETCH NEXT FROM nosa INTO @dbname 
WHILE @@FETCH_STATUS = 0  
BEGIN  
	  SET @selectdb = ('ALTER AUTHORIZATION ON DATABASE::' + @dbname + ' to sa')
	  EXEC sp_executesql @selectdb
      FETCH NEXT FROM nosa INTO @dbname 
END 

CLOSE nosa  
DEALLOCATE nosa
--EXEC sp_changedbowner 'SA'



