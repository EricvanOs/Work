DECLARE 
@recip VARCHAR(50),
@subj VARCHAR(50),
@msg VARCHAR(200)

SET @recip = 'marco.baars@cygnific.com'
SET @subj = 'Testmail'
SET @msg = 'tralala'


EXEC msdb.dbo.sp_send_dbmail
		@profile_name = 'Alerting Profile',
		@recipients = @recip,
		@subject = @subj,
		@body = @msg

--https://docs.microsoft.com/en-us/sql/relational-databases/system-stored-procedures/sp-send-dbmail-transact-sql?view=sql-server-ver15

