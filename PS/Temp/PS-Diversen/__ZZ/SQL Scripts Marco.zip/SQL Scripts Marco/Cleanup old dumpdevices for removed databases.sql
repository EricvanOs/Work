----------------------------------------------------------------------
--
-- Added procedure to cleanup old dump devices and backup files
-- Date: 23-11-2017
-- Author: Marco Baars
--
----------------------------------------------------------------------

DECLARE @dmpdevice	varchar(100)
DECLARE @dbname	varchar(100)

--Make collection of available dump devices
SELECT [name] INTO #dumpdevicenames FROM master..sysdevices
ORDER BY name ASC 

-- Now open cursor from temp table and check dump devices
BEGIN
DECLARE DMPCURS CURSOR FOR
SELECT [name] FROM #dumpdevicenames

OPEN DMPCURS

FETCH DMPCURS INTO @dmpdevice
WHILE @@FETCH_STATUS = 0

	BEGIN
		 
		 --Construct database name from dumpdevicename
		 SET @dbname  = (SELECT REPLACE(@dmpdevice,'_DumpDevice',''))

		 --Check if database still exists and remove dumpdevice if required
		 IF not exists (SELECT 1 FROM sys.databases WHERE name = @dbname)
		 BEGIN
			Print 'Removing ' + @dmpdevice
			--Removing dump device
			EXEC sp_dropdevice @dmpdevice, 'delfile'
			--Write to log
				INSERT INTO [DatabaseAdministration].[dbo].[tbl_backup_log]
				(logmessage,datetimelog) VALUES ('Removing dump device ' + @dbname + ' and backup files',GETDATE())
		 END

		 FETCH DMPCURS INTO @dmpdevice
	END

CLOSE DMPCURS
DEALLOCATE DMPCURS
DROP TABLE #dumpdevicenames
END