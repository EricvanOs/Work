#region Load snappins
if (Get-PSSnapin -Name quest.activeroles.admanagement 2>$null) {}
else    {Add-PSSnapin -Name quest.activeroles.admanagement}
#endregion
cls
#region Query KACE

$conn = New-Object Data.Odbc.OdbcConnection
$conn.ConnectionString = "dsn=K1000"
$cmd = New-Object System.Data.SqlClient.SqlCommand
$cmd = $conn.CreateCommand()
$cmd.CommandText = "select NAME AS MNAME,CS_MODEL,BIOS_SERIAL_NUMBER,LAST_USER,IP from MACHINE order by MNAME"

$conn.Open() 
$dbcomputers =  @()

do{
    try{
        $rdr = $cmd.ExecuteReader()
		
        while ($rdr.read())
		{
		<#
			Write-Host -ForegroundColor Red  $rdr.GetValue(0)
			Write-Host $rdr.GetValue(1)
			Write-Host $rdr.GetValue(2)
			Write-Host $rdr.GetValue(3)
			Write-Host $rdr.GetValue(4)
		#>
			$dbcomputers += ,@($rdr.GetValue(0),$rdr.GetValue(1), $rdr.GetValue(2),$rdr.GetValue(3), $rdr.GetValue(4))
			#if($rdr.GetValue(0) -eq 'cyg6500')
			#{
				Write-Host "Name: " $rdr.GetValue(0)
				write-host "Model: " $rdr.GetValue(1)
				write-host "Bios Serial: "$rdr.GetValue(2)
				write-host "Last user: " $rdr.GetValue(3)
				write-host "IP: "$rdr.GetValue(4)
			#}
        }
        $transactionComplete = $true
		
    }
    catch{
        $transactionComplete = $false
    }
}until ($transactionComplete)

# Close the database connection

$conn.Close()

#endregion