-- find orphaned users from windows/certificate/asymmetric_key login
		select  dp.name, dp.type, dp.sid, LEN(dp.sid) as [SID_Len] 
		from sys.database_principals dp
		left join sys.server_principals sp
		on dp.sid = sp.sid
		left join sys.certificates c
		on dp.sid = c.sid
		left join sys.asymmetric_keys a
		on dp.sid = a.sid
		where sp.sid is null and c.sid is null and a.sid is null
		-- check dp.type, go to the following
		--https://docs.microsoft.com/en-us/sql/relational-databases/system-catalog-views/sys-database-principals-transact-sql
		and dp.type in ('U', 'S', 'C', 'K') 
		and dp.principal_id > 4 -- 0..4 are system users which will be ignored
		and not (dp.type = 'S' and LEN(dp.sid) = 28) -- to filter out the valid db users without login