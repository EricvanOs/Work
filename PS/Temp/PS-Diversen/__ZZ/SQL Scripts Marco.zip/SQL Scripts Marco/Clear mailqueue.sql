--Used when mailqueue is flooded by an external problem
--I used this in the past when an application was sending mail constantly and slowing down the server

delete from msdb.dbo.sysmail_unsentitems 
where send_request_user >= '09-01-2015' and subject = 'Invoice DI, Not able to send an email regarding Email.'

delete  from msdb.dbo.sysmail_faileditems