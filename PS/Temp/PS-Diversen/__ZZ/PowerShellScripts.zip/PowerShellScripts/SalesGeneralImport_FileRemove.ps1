$StartFolder = '\\cyg7006\data\P&R\Reporting\Data_Sources\Sales\Source\PVECYG'
Remove-Item -Path ($StartFolder + "\" +"Cygnific_Sales.csv") 