﻿$ColumnList = "lastname","email"

$fileInput = Import-CSV test3.csv


$fileInput | Select-Object -Property $ColumnList | export-csv test3Output.csv -notype



####

invoke-sqlcmd 