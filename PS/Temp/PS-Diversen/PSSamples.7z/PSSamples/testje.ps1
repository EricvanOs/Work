﻿$ErrorActionPreference="stop"
#$ErrorActionPreference="silentlycontinue"
#$ErrorActionPreference="inquire"
#$ErrorActionPreference="continue"
Get-WmiObject -Class bestaatniet
get-service  Spooler
