﻿Get-Process -Name POWERPNT | select Modules
Get-Process -Name POWERPNT | select -ExpandProperty Modules

